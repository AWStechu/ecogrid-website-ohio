#!/bin/bash
cd /Users/muneebwa/ecogrid-website
source venv/bin/activate
python app.py
